/*
 *Kaiming Cui
 *CSCI 503
 *Lab4
 *The tar ball "Lab4_KaimingCui.tar" contains 2 file directories: BasicElevator and ImprovedElevator. Each directory contains four items: a executable file "BasicElevator.out or ImprovedElevator.out", a source code file "source.c", a Makefile a README.txt, and this header.h file.
 */
